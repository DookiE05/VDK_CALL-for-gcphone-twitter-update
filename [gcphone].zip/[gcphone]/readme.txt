This a vdk_call for gcphone twitter update. This is not the lasted version of the gcphone, but vdk_call and gcphone is work fine for me.

Credits:-Gannon001 for gcphone
		-vodkhard for vdk_call